import React from 'react';

const Footer=()=>{
    return(

        <div>
            &copy; Copyrights Reserved.
        </div>

    )
}
export default Footer;